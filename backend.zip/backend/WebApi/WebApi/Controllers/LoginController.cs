﻿using Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Model.DTOs;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ILoginManager loginManager;
        public LoginController(ILoginManager loginManager)
        {
            this.loginManager = loginManager;
        }

        [HttpPost]
        public async Task<IActionResult> LogIn([FromBody] LoginDto login)
        {
            try
            {
                if (await loginManager.LoginAsync(login.Username, login.Password))
                {
                    return Ok($"{login.Username} logged");
                }
                return BadRequest();
            }
            catch (Exception e)
            {

                return StatusCode(500, e.Message);
            }
            
        }
    }
}

export class Usuario{
    nombreUsuario?: string;
    password?: string;
}
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http' 
import { Observable } from 'rxjs';
import { Usuario } from '../models/usuario';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }

  logIn(usuario: Usuario): Observable<any> {
    return this.http.post('http://localhost:5094/api/Login',{ username:usuario.nombreUsuario, password: usuario.password}); 
  }
}
